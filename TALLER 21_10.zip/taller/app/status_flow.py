from PySide6.QtCore import Qt
from PySide6.QtWidgets import QPushButton

from app.schema import ESTADO_COLORS


def _rgba(hex_color: str, alpha: float) -> str:
    """Convierte un color #RRGGBB a rgba(...) con la transparencia dada,
    porque las hojas de estilo de Qt no soportan bien el formato #RRGGBBAA."""
    r, g, b = int(hex_color[1:3], 16), int(hex_color[3:5], 16), int(hex_color[5:7], 16)
    return f"rgba({r},{g},{b},{alpha})"


class StatusStep(QPushButton):
    def __init__(self, index: int, title: str, parent=None):
        super().__init__(parent)
        self.index = index
        self.title = title
        self.setCheckable(True)
        self.setMinimumHeight(76)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setText(f"{index + 1}\n{title}")
        # Cada etapa tiene su propio color "semáforo": rojo = recién llegó,
        # ámbar = en proceso, verde = terminado. Así se nota de un vistazo en
        # qué etapa va la orden sin tener que leer el texto.
        color = ESTADO_COLORS.get(title, "#A8232A")
        self.setStyleSheet(f"""
            QPushButton {{ border: 1px solid {_rgba(color, 0.4)}; border-radius: 12px; background: #1E1E1E;
                          color: {color}; font-size: 14px; font-weight: 600; padding: 8px 18px; }}
            QPushButton:hover {{ border: 1px solid {color}; color: #EDEDED; background: {_rgba(color, 0.18)}; }}
            QPushButton:checked {{ background: {color}; color: white; border: 1px solid {color}; }}
        """)

    def set_active(self, active: bool) -> None:
        """Marca o desmarca el paso, forzando que Qt repinte el estilo.

        Qt a veces no vuelve a evaluar la hoja de estilo (el color de fondo
        que depende de :checked) cuando el cambio viene del código en vez de
        un clic directo del usuario, así que el botón se queda visualmente
        "atorado" aunque el dato ya haya cambiado. unpolish/polish fuerza
        ese repintado inmediato.
        """
        self.setChecked(active)
        self.style().unpolish(self)
        self.style().polish(self)
        self.update()
