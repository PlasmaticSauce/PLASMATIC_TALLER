"""Datos del taller que aparecen en la orden impresa / PDF.

Edita los valores de abajo con la información real del negocio.
El logo ya está cargado en data/logo.png (se recortó del membretado que nos
compartieron). La barra de color del PDF no usa una imagen aparte, se dibuja
con celdas de color directamente en la plantilla.
"""
from pathlib import Path

TALLER_NOMBRE = "Suspensiones Sor Juana"

# Puede ser una sola sucursal (texto) o varias (lista de textos), una por línea.
TALLER_DIRECCION = (
    "Av. Texcoco 324, Juan Escutia, Iztapalapa, 09100 Ciudad de México, CDMX",
    "Av. Sor Juana Inés de la Cruz #615, Benito Juárez, 57000 Ciudad de México",
)

TALLER_TELEFONO = ""   # Pendiente: agregar cuando nos den el número de contacto.
TALLER_CORREO = ""     # Ej. "contacto@suspensionessorjuana.com"

_DATA_DIR = Path(__file__).resolve().parent.parent / "data"
LOGO_PATH = _DATA_DIR / "logo.png"
