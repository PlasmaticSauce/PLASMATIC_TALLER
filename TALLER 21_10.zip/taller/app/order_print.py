"""Impresión y exportación a PDF de órdenes de trabajo.

El formato replica el diseño de referencia proporcionado por el negocio
(franja de folio/fechas/estado, bloques con encabezado oscuro, tabla de
conceptos con precio unitario, pagos + total, entrega/observaciones y firmas).
"""
from pathlib import Path

from PySide6.QtCore import QMarginsF, QSizeF
from PySide6.QtGui import QPageSize, QPageLayout, QTextDocument
from PySide6.QtPrintSupport import QPrinter, QPrintDialog
from PySide6.QtWidgets import QFileDialog, QMessageBox

from app.config import TALLER_NOMBRE, TALLER_DIRECCION, TALLER_TELEFONO, TALLER_CORREO, LOGO_PATH
from app.schema import ESTADO_COLORS

DARK = "#374151"        # barras de encabezado de sección
TITLE = "#1f2937"       # título principal
LIGHT_BG = "#f3f4f6"    # franja folio/fecha/estado y encabezados de tabla
TOTAL_BG = "#e5e7eb"    # fila de total destacada
BORDER = "#d7dbe0"      # líneas de la cuadrícula
MUTED = "#6b7280"       # texto secundario / etiquetas


class OrderPrintService:
    def __init__(self, parent, db, order_id: int):
        self.parent = parent
        self.db = db
        self.order_id = order_id

    def _data(self):
        return self.db.order_detail(self.order_id)

    @staticmethod
    def _esc(value) -> str:
        import html
        return html.escape(str(value or "")) or "—"

    @staticmethod
    def _fecha(value) -> str:
        from datetime import datetime
        try:
            return datetime.strptime(value, "%Y-%m-%d").strftime("%d/%m/%Y")
        except (ValueError, TypeError):
            return value or ""

    @staticmethod
    def _section_bar(title: str) -> str:
        return (
            f"<table style='border:0;border-collapse:collapse;width:100%;margin-top:14px'><tr>"
            f"<td style='border:0;background:{DARK};color:#fff;font-weight:bold;"
            f"font-size:9.5pt;letter-spacing:.5px;padding:6px 10px'>{title}</td>"
            f"</tr></table>"
        )

    # ---------- encabezado ----------
    def _header_html(self) -> str:
        logo_html = (
            f"<img src='{LOGO_PATH.as_uri()}' height='95' />"
            if LOGO_PATH.exists() else f"<b style='font-size:14pt'>{self._esc(TALLER_NOMBRE)}</b>"
        )
        return f"""
        <table style='border:0;border-collapse:collapse;width:100%'><tr>
          <td style='border:0;padding:0;width:32%;vertical-align:middle'>{logo_html}</td>
          <td style='border:0;padding:0;vertical-align:middle;text-align:right'>
            <div style='color:{TITLE};font-size:22pt;font-weight:bold'>ORDEN DE TRABAJO</div>
            <div style='color:{MUTED};font-size:9pt;font-weight:bold;margin-top:2px'>Servicio y mantenimiento automotriz</div>
          </td>
        </tr></table>
        <div style='border-top:2px solid {DARK};margin-top:10px'></div>
        """

    # ---------- franja folio / fechas / estado ----------
    def _folio_strip_html(self, row) -> str:
        estado = row.get("estado") or ""
        color = ESTADO_COLORS.get(estado, DARK)
        cierre = self._fecha(row.get("fecha_cierre"))

        def cell(label, value, color=None, width=None):
            w = f"width:{width};" if width else ""
            c = color or "#111"
            return (
                f"<td style='border:0;{w}padding:9px 10px;vertical-align:top'>"
                f"<div style='color:{MUTED};font-size:7.5pt;font-weight:bold;letter-spacing:.5px'>{label}</div>"
                f"<div style='color:{c};font-size:11.5pt;font-weight:bold;margin-top:2px'>{value}</div>"
                f"</td>"
            )

        return f"""
        <table style='border:0;border-collapse:collapse;width:100%;background:{LIGHT_BG};margin-top:0'><tr>
          {cell("FOLIO", f"OT-{self.order_id:05d}", width="22%")}
          {cell("FECHA DE ORDEN", self._esc(self._fecha(row.get('fecha'))), width="26%")}
          {cell("FECHA DE CIERRE", self._esc(cierre) if cierre else "—", width="26%")}
          {cell("ESTADO", self._esc(estado).upper(), color=color)}
        </tr></table>
        """

    # ---------- datos del cliente ----------
    def _cliente_html(self, row) -> str:
        tel = row.get("cliente_telefono")
        body = f"""
        <table style='border:0;border-collapse:collapse;width:100%'><tr>
          <td style='border:0;padding:9px 10px;width:60%;vertical-align:top'>
            <div style='color:{MUTED};font-size:7.5pt;font-weight:bold'>CLIENTE</div>
            <div style='font-size:10.5pt;margin-top:2px'>{self._esc(row.get('cliente'))}</div>
          </td>
          <td style='border:0;padding:9px 10px;vertical-align:top'>
            <div style='color:{MUTED};font-size:7.5pt;font-weight:bold'>TELÉFONO</div>
            <div style='font-size:10.5pt;margin-top:2px'>{self._esc(tel) if tel else '—'}</div>
          </td>
        </tr></table>
        """
        return self._section_bar("DATOS DEL CLIENTE") + body

    # ---------- datos del vehículo ----------
    def _vehiculo_html(self, row) -> str:
        body = f"""
        <table style='border:0;border-collapse:collapse;width:100%'><tr>
          <td style='border:0;padding:9px 10px;width:40%;vertical-align:top'>
            <div style='color:{MUTED};font-size:7.5pt;font-weight:bold'>VEHÍCULO</div>
            <div style='font-size:10.5pt;margin-top:2px'>{self._esc(row.get('vehiculo') or 'Sin vehículo')}</div>
          </td>
          <td style='border:0;padding:9px 10px;width:30%;vertical-align:top'>
            <div style='color:{MUTED};font-size:7.5pt;font-weight:bold'>PLACAS</div>
            <div style='font-size:10.5pt;margin-top:2px'>{self._esc(row.get('placas') or 'Sin placas')}</div>
          </td>
          <td style='border:0;padding:9px 10px;vertical-align:top'>
            <div style='color:{MUTED};font-size:7.5pt;font-weight:bold'>KILOMETRAJE</div>
            <div style='font-size:10.5pt;margin-top:2px'>{self._esc(row.get('kilometraje'))}</div>
          </td>
        </tr></table>
        """
        return self._section_bar("DATOS DEL VEHÍCULO") + body

    # ---------- servicios / conceptos ----------
    def _conceptos_html(self) -> str:
        items = self.db.order_items(self.order_id)
        header = (
            f"<tr style='background:{LIGHT_BG}'>"
            f"<th style='border:1px solid {BORDER};padding:6px 10px;text-align:left;font-size:8pt;width:10%'>CANT.</th>"
            f"<th style='border:1px solid {BORDER};padding:6px 10px;text-align:left;font-size:8pt'>DESCRIPCIÓN</th>"
            f"<th style='border:1px solid {BORDER};padding:6px 10px;text-align:right;font-size:8pt;width:18%'>PRECIO</th>"
            f"<th style='border:1px solid {BORDER};padding:6px 10px;text-align:right;font-size:8pt;width:18%'>TOTAL</th>"
            f"</tr>"
        )
        if items:
            rows = "".join(
                "<tr>"
                f"<td style='border:1px solid {BORDER};padding:7px 10px;text-align:center'>{it['cantidad']:g}</td>"
                f"<td style='border:1px solid {BORDER};padding:7px 10px'>{self._esc(it['descripcion']).upper()}</td>"
                f"<td style='border:1px solid {BORDER};padding:7px 10px;text-align:right'>${it['precio_unitario']:,.2f}</td>"
                f"<td style='border:1px solid {BORDER};padding:7px 10px;text-align:right'>${it['subtotal']:,.2f}</td>"
                "</tr>"
                for it in items
            )
        else:
            row = self._data() or {}
            rows = (
                f"<tr><td style='border:1px solid {BORDER};padding:7px 10px' colspan='4'>"
                f"{self._esc(row.get('servicio') or 'Sin conceptos capturados')}</td></tr>"
            )
        table = f"<table style='border:1px solid {BORDER};border-collapse:collapse;width:100%;font-size:9.5pt'>{header}{rows}</table>"
        return self._section_bar("SERVICIOS / CONCEPTOS") + table

    # ---------- pagos + total ----------
    def _pagos_html(self, row) -> str:
        total = float(row.get("costo") or 0)
        payments = self.db.payments_for_order(self.order_id)
        header = (
            f"<tr style='background:{LIGHT_BG}'>"
            f"<th style='border:1px solid {BORDER};padding:6px 10px;text-align:left;font-size:8pt'>FECHA</th>"
            f"<th style='border:1px solid {BORDER};padding:6px 10px;text-align:left;font-size:8pt'>MÉTODO</th>"
            f"<th style='border:1px solid {BORDER};padding:6px 10px;text-align:right;font-size:8pt'>IMPORTE</th>"
            f"</tr>"
        )
        if payments:
            rows = "".join(
                "<tr>"
                f"<td style='border:1px solid {BORDER};padding:7px 10px'>{self._esc(self._fecha(p['fecha']))}</td>"
                f"<td style='border:1px solid {BORDER};padding:7px 10px'>{self._esc(p['metodo'])}"
                f"{(' · ' + self._esc(p['referencia'])) if p.get('referencia') else ''}</td>"
                f"<td style='border:1px solid {BORDER};padding:7px 10px;text-align:right'>${p['monto']:,.2f}</td>"
                "</tr>"
                for p in payments
            )
        else:
            rows = f"<tr><td style='border:1px solid {BORDER};padding:7px 10px' colspan='3'>Sin pagos registrados</td></tr>"
        total_row = f"""
        <table style='border:1px solid {BORDER};border-top:0;border-collapse:collapse;width:100%;background:{TOTAL_BG}'><tr>
          <td style='border:0;padding:10px;font-size:11pt;font-weight:bold;text-align:right'>TOTAL DE LA ORDEN</td>
          <td style='border:0;padding:10px;font-size:13pt;font-weight:bold;text-align:right;width:20%'>${total:,.2f}</td>
        </tr></table>
        """
        table = f"<table style='border:1px solid {BORDER};border-collapse:collapse;width:100%;font-size:9.5pt'>{header}{rows}</table>"
        return self._section_bar("PAGOS REGISTRADOS") + table + total_row

    # ---------- fotos (si hay) ----------
    def _fotos_html(self) -> str:
        photos = self.db.order_photos(self.order_id)
        cells = []
        for p in photos:
            path = Path(p["ruta"])
            if not path.exists():
                continue
            caption = self._esc(self._fecha(p.get("fecha")))
            cells.append(
                f"<td style='border:0;text-align:center;padding:6px'>"
                f"<img src='{path.as_uri()}' width='150' /><br>"
                f"<span style='color:{MUTED};font-size:8pt'>{caption}</span></td>"
            )
        if not cells:
            return ""
        per_row = 3
        rows = "".join("<tr>" + "".join(cells[i:i + per_row]) + "</tr>" for i in range(0, len(cells), per_row))
        table = f"<table style='border:0;border-collapse:collapse;width:100%'>{rows}</table>"
        return self._section_bar("FOTOS") + table

    # ---------- entrega y observaciones ----------
    def _entrega_html(self, row) -> str:
        direcciones = TALLER_DIRECCION
        if isinstance(direcciones, str):
            direcciones = [direcciones] if direcciones else []
        dir_html = "<br>".join(self._esc(d) for d in direcciones) if direcciones else ""
        cierre = self._fecha(row.get("fecha_cierre"))
        notas = row.get("notas")
        observ = self._esc(notas) if notas else "_" * 42

        body = f"""
        <table style='border:0;border-collapse:collapse;width:100%'><tr>
          <td style='border:0;padding:9px 10px;width:52%;vertical-align:top;font-size:9.5pt'>
            <b>Fecha de entrega:</b> {self._esc(cierre) if cierre else "_______________"}
            <div style='margin-top:10px;color:{MUTED};font-size:8pt;font-weight:bold'>DIRECCIÓN REGISTRADA:</div>
            <div style='font-size:8.5pt;color:#444;margin-top:2px;line-height:1.4'>{dir_html}</div>
          </td>
          <td style='border:0;padding:9px 10px;vertical-align:top;font-size:9.5pt'>
            <b>Observaciones:</b> {observ}
          </td>
        </tr></table>
        """
        return self._section_bar("ENTREGA Y OBSERVACIONES") + body

    # ---------- firmas ----------
    def _firmas_html(self) -> str:
        return f"""
        <table style='border:0;border-collapse:collapse;width:100%;margin-top:34px'><tr>
          <td style='border:0;padding:0;width:46%;text-align:center'>
            <div style='border-top:1px solid #202020;padding-top:6px;font-weight:bold;font-size:9pt'>FIRMA DEL CLIENTE</div>
          </td>
          <td style='border:0;padding:0;width:8%'></td>
          <td style='border:0;padding:0;text-align:center'>
            <div style='border-top:1px solid #202020;padding-top:6px;font-weight:bold;font-size:9pt'>FIRMA DEL TALLER</div>
          </td>
        </tr></table>
        """

    def html(self) -> str:
        row = self._data()
        if not row:
            return ""
        return f"""
        <html><head><meta charset='utf-8'><style>
        body {{ font-family: Arial, sans-serif; color:#111827; font-size:10pt; margin:0; padding:0; }}
        table {{ border-collapse:collapse; }}
        </style></head><body>
        {self._header_html()}
        {self._folio_strip_html(row)}
        {self._cliente_html(row)}
        {self._vehiculo_html(row)}
        {self._conceptos_html()}
        {self._pagos_html(row)}
        {self._fotos_html()}
        {self._entrega_html(row)}
        {self._firmas_html()}
        <p style='color:#9ca3af;font-size:7.5pt;margin-top:16px'>Documento generado por el sistema de gestión del taller • Folio OT-{self.order_id:05d}</p>
        </body></html>
        """

    def _configured_printer(self):
        printer = QPrinter(QPrinter.PrinterMode.HighResolution)
        printer.setPageSize(QPageSize(QPageSize.PageSizeId.Letter))
        printer.setPageMargins(QMarginsF(13, 12, 13, 12), QPageLayout.Unit.Millimeter)
        return printer

    def _build_document(self, printer) -> QTextDocument:
        """Arma el documento y lo ajusta al tamaño físico de la hoja.

        Sin esto, Qt dibuja el documento a su ancho "de pantalla" (mucho más
        chico que la resolución real de impresión) y el resultado sale
        diminuto, pegado en una esquina, con la hoja casi toda en blanco.
        Hay que decirle explícitamente qué tan grande es la página en
        píxeles, a la resolución con la que se va a imprimir.
        """
        doc = QTextDocument()
        doc.documentLayout().setPaintDevice(printer)
        page_rect = printer.pageLayout().paintRectPixels(printer.resolution())
        doc.setPageSize(QSizeF(page_rect.size()))
        doc.setHtml(self.html())
        return doc

    def print_order(self):
        if not self._data():
            return
        printer = self._configured_printer()
        dialog = QPrintDialog(printer, self.parent)
        dialog.setWindowTitle("Imprimir orden de trabajo")
        if dialog.exec():
            doc = self._build_document(printer)
            doc.print_(printer)

    def save_pdf(self):
        if not self._data():
            return
        default_name = f"OT-{self.order_id:05d}.pdf"
        path, _ = QFileDialog.getSaveFileName(
            self.parent, "Guardar orden como PDF", str(Path.home() / default_name), "PDF (*.pdf)"
        )
        if not path:
            return
        if not path.lower().endswith(".pdf"):
            path += ".pdf"
        printer = self._configured_printer()
        printer.setOutputFormat(QPrinter.OutputFormat.PdfFormat)
        printer.setOutputFileName(path)
        doc = self._build_document(printer)
        doc.print_(printer)
        QMessageBox.information(self.parent, "PDF creado", f"La orden OT-{self.order_id:05d} se guardó correctamente.\n\n{path}")
