"""Ventana principal del sistema del taller."""
from PySide6.QtCore import QEasingCurve, QPropertyAnimation
from PySide6.QtWidgets import QGraphicsOpacityEffect, QMainWindow, QTabWidget

from app.crud import CrudTab
from app.dashboard import DashboardTab
from app.reports import ReportsTab
from app.schema import CLIENTES, ORDENES, PROVEEDORES, SERVICIOS, VEHICULOS


class MainWindow(QMainWindow):
    def __init__(self, db):
        super().__init__()
        self.setWindowTitle("Taller Mecánico")
        self.resize(1350, 780)

        # Los pagos ya no tienen una pestaña aparte propia (la que existía
        # mostraba todas las órdenes y se solapaba con esta lista). Se pueden
        # registrar desde aquí mismo (fila seleccionada), desde "Ver orden",
        # o desde "Pagos pendientes" en Reportes. El dinero cobrado/por
        # cobrar se sigue viendo en Dashboard y Reportes.
        pages = [
            (DashboardTab(db), "Dashboard"),
            (CrudTab(db, ORDENES), ORDENES.title),
            (CrudTab(db, CLIENTES, history_mode="client"), CLIENTES.title),
            (CrudTab(db, VEHICULOS, history_mode="vehicle"), VEHICULOS.title),
            (CrudTab(db, PROVEEDORES), PROVEEDORES.title),
            (CrudTab(db, SERVICIOS), SERVICIOS.title),
            (ReportsTab(db), "Reportes"),
        ]
        self.tabs = QTabWidget()
        for page, title in pages:
            self.tabs.addTab(page, title)
        self.tabs.currentChanged.connect(self._on_tab_changed)
        self.setCentralWidget(self.tabs)

    def _on_tab_changed(self, index: int) -> None:
        page = self.tabs.widget(index)
        if page is None:
            return
        if hasattr(page, "refresh"):
            page.refresh()
        self._fade_in(page)

    @staticmethod
    def _fade_in(widget) -> None:
        """Pequeño efecto de aparición al entrar a una pestaña, para que el
        cambio se sienta menos brusco."""
        effect = QGraphicsOpacityEffect(widget)
        widget.setGraphicsEffect(effect)
        anim = QPropertyAnimation(effect, b"opacity", widget)
        anim.setDuration(220)
        anim.setStartValue(0.0)
        anim.setEndValue(1.0)
        anim.setEasingCurve(QEasingCurve.Type.OutCubic)
        anim.finished.connect(lambda: widget.setGraphicsEffect(None))
        # Se guarda en el propio widget para que Python no la recolecte
        # como basura antes de que termine de correr.
        widget._fade_anim = anim
        anim.start()
