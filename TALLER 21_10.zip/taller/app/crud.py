"""Componentes reutilizables de altas, edición, bajas e historial."""
from PySide6.QtCore import QDate
from PySide6.QtWidgets import (
    QAbstractItemView, QComboBox, QDateEdit, QDialog, QDialogButtonBox,
    QDoubleSpinBox, QFormLayout, QFrame, QHBoxLayout, QHeaderView, QLabel,
    QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QScrollArea,
    QTableWidget, QTableWidgetItem, QVBoxLayout, QWidget,
)

from PySide6.QtGui import QColor

from app.schema import ENTITIES, Entity, Field, ESTADO_COLORS, PAGO_COLORS
from app.order_detail import OrderDetailDialog
from app.order_items import OrderItemsEditor
from app.widgets import make_searchable, sync_combo_text

DB_DATE = "yyyy-MM-dd"
SHOW_DATE = "dd/MM/yyyy"


class RecordDialog(QDialog):
    def __init__(self, parent, db, entity: Entity, record: dict | None = None):
        super().__init__(parent)
        self.db, self.entity = db, entity
        self.result_values: dict = {}
        verb = "Editar" if record else "Dar de alta"
        self.setWindowTitle(f"{verb} {entity.singular}")
        self.setMinimumWidth(500)

        form = QFormLayout()
        form.setSpacing(12)
        self.inputs: dict[str, QWidget] = {}
        # En una orden, el detalle del servicio se captura como conceptos (ver
        # más abajo) en vez de en un cuadro de texto libre; el campo sigue
        # existiendo internamente (se autogenera a partir de los conceptos)
        # para no perder compatibilidad con reportes e historial antiguos.
        hidden_fields = {"servicio"} if entity.table == "ordenes" else set()
        for f in entity.fields:
            widget = self._make_input(f)
            self.inputs[f.key] = widget
            if f.key in hidden_fields:
                continue
            form.addRow(f.label + (" *" if f.required else ""), widget)
        self._setup_vehicle_dependency()

        self.items_editor = None
        if entity.table == "ordenes":
            self.items_editor = OrderItemsEditor(self, db)
            self.items_editor.on_change = self._sync_from_items

        if record:
            self._load(record)
            if self.items_editor:
                self.items_editor.load(db.order_items(record["id"]))

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel
        )
        save = buttons.button(QDialogButtonBox.StandardButton.Save)
        save.setText("Guardar")
        save.setObjectName("primary")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        buttons.accepted.connect(self._validate_and_accept)
        buttons.rejected.connect(self.reject)

        # El contenido va dentro de un área con scroll para que, si el
        # formulario no cabe en la pantalla, siempre se puedan ver y usar los
        # botones de Guardar/Cancelar al final.
        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(16)
        content_layout.addLayout(form)
        if self.items_editor:
            items_title = QLabel("Conceptos / servicios *")
            items_title.setObjectName("sectionTitle")
            content_layout.addWidget(items_title)
            content_layout.addWidget(self.items_editor)
        content_layout.addStretch()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(content)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 20)
        layout.setSpacing(16)
        layout.addWidget(scroll)
        layout.addWidget(buttons)

        if self.items_editor:
            self.setMinimumWidth(560)
        self.resize(self.minimumWidth() or 500, 640)

    def _sync_from_items(self) -> None:
        if self.items_editor is None:
            return
        items = self.items_editor.get_items()
        costo_widget = self.inputs.get("costo")
        if costo_widget is not None:
            if items:
                costo_widget.setValue(self.items_editor.total())
                costo_widget.setEnabled(False)
            else:
                costo_widget.setEnabled(True)
        # El resumen de "servicio" (usado en la lista, reportes e historial)
        # se arma solo con las descripciones de los conceptos capturados.
        servicio_widget = self.inputs.get("servicio")
        if servicio_widget is not None and items:
            servicio_widget.setPlainText("; ".join(it["descripcion"] for it in items))

    def get_items(self) -> list[dict]:
        return self.items_editor.get_items() if self.items_editor else []

    def _make_input(self, f: Field) -> QWidget:
        if f.kind == "multiline":
            w = QPlainTextEdit()
            w.setFixedHeight(90)
            return w
        if f.kind == "number":
            w = QDoubleSpinBox()
            w.setRange(0, 99_999_999)
            w.setDecimals(2)
            w.setPrefix("$ ")  # todos los campos numéricos del sistema son montos en dinero
            w.setGroupSeparatorShown(True)
            return w
        if f.kind == "date":
            w = QDateEdit(QDate.currentDate())
            w.setCalendarPopup(True)
            w.setDisplayFormat(SHOW_DATE)
            return w
        if f.kind == "choice":
            w = QComboBox()
            w.addItems(f.options)
            return w
        if f.kind == "ref":
            w = QComboBox()
            for record_id, label in self.db.ref_options(f.ref):
                w.addItem(label, record_id)
            make_searchable(w)
            return w
        return QLineEdit()

    def _setup_vehicle_dependency(self) -> None:
        # En una orden solo deben aparecer los vehículos del cliente seleccionado.
        if "cliente_id" not in self.inputs or "vehiculo_id" not in self.inputs:
            return
        client = self.inputs["cliente_id"]
        vehicle = self.inputs["vehiculo_id"]

        def reload_vehicles(client_id):
            current = vehicle.currentData()
            vehicle.blockSignals(True)
            vehicle.clear()
            for record_id, label in self.db.ref_options("vehiculos", client_id=client_id):
                vehicle.addItem(label, record_id)
            if current is not None:
                idx = vehicle.findData(current)
                if idx >= 0:
                    vehicle.setCurrentIndex(idx)
            vehicle.blockSignals(False)

        client.currentIndexChanged.connect(lambda _index: reload_vehicles(client.currentData()))
        reload_vehicles(client.currentData())

    def _load(self, record: dict) -> None:
        for f in self.entity.fields:
            w, value = self.inputs[f.key], record.get(f.key)
            if f.kind == "multiline":
                w.setPlainText(value or "")
            elif f.kind == "number":
                w.setValue(float(value or 0))
            elif f.kind == "date":
                date = QDate.fromString(value or "", DB_DATE)
                if date.isValid():
                    w.setDate(date)
            elif f.kind == "choice":
                w.setCurrentText(value or "")
            elif f.kind == "ref":
                idx = w.findData(value)
                if idx >= 0:
                    w.setCurrentIndex(idx)
            else:
                w.setText(str(value or ""))

    def _values(self) -> dict:
        values = {}
        for f in self.entity.fields:
            w = self.inputs[f.key]
            if f.kind == "multiline":
                values[f.key] = w.toPlainText().strip()
            elif f.kind == "number":
                values[f.key] = w.value()
            elif f.kind == "date":
                values[f.key] = w.date().toString(DB_DATE)
            elif f.kind == "choice":
                values[f.key] = w.currentText()
            elif f.kind == "ref":
                values[f.key] = w.currentData()
            else:
                values[f.key] = w.text().strip()
        return values

    def _validate_and_accept(self) -> None:
        # Antes de leer los valores, el texto escrito en los buscadores debe
        # coincidir con la opción realmente seleccionada (si no, se podría
        # guardar el cliente o vehículo equivocado sin darse cuenta).
        for f in self.entity.fields:
            if f.kind == "ref" and not sync_combo_text(self.inputs[f.key], strict=True):
                QMessageBox.warning(
                    self, "Elige una opción de la lista",
                    f"Lo que escribiste en «{f.label}» no coincide con ningún registro. "
                    "Escribe para buscar y elige uno de la lista desplegable.",
                )
                self.inputs[f.key].setFocus()
                return
        values = self._values()
        for f in self.entity.fields:
            if f.key in ({"servicio"} if self.entity.table == "ordenes" else set()):
                continue
            if f.required and values[f.key] in ("", None):
                if f.key == "vehiculo_id" and "cliente_id" in values:
                    msg = "Este cliente no tiene vehículos registrados. Da de alta uno en «Vehículos» primero."
                elif f.kind == "ref":
                    msg = f"Primero da de alta al menos un registro en «{ENTITIES[f.ref].title}»."
                else:
                    msg = f"El campo «{f.label}» es obligatorio."
                QMessageBox.warning(self, "Falta información", msg)
                return
        if self.items_editor is not None and not self.items_editor.get_items():
            QMessageBox.warning(
                self, "Falta información",
                "Agrega al menos un concepto en «Conceptos / servicios» antes de guardar la orden.",
            )
            return
        self.result_values = values
        self.accept()


class HistoryDialog(QDialog):
    """Historial de órdenes de un cliente o vehículo."""
    def __init__(self, parent, db, *, client_id=None, vehicle_id=None, title="Historial"):
        super().__init__(parent)
        self.db = db
        self.client_id = client_id
        self.vehicle_id = vehicle_id
        self.setWindowTitle(title)
        self.resize(850, 480)

        self.info = QLabel()
        self.info.setObjectName("sectionTitle")
        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["OT", "Fecha", "Vehículo", "Placas", "Estado", "Total"]
        )
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.NoSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)

        close = QPushButton("Cerrar")
        close.clicked.connect(self.accept)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(12)
        layout.addWidget(self.info)
        layout.addWidget(self.table)
        layout.addWidget(close)
        self.refresh()

    def refresh(self):
        if self.vehicle_id:
            vehicle = self.db.conn.execute(
                "SELECT marca, modelo, placas FROM vehiculos WHERE id = ?", (self.vehicle_id,)
            ).fetchone()
            rows = self.db.vehicle_history(self.vehicle_id)
            name = " ".join(x for x in (vehicle[0], vehicle[1]) if x) if vehicle else "Vehículo"
            self.info.setText(f"Historial de {name} · {vehicle[2] if vehicle and vehicle[2] else 'Sin placas'}")
        else:
            client = self.db.conn.execute(
                "SELECT nombre FROM clientes WHERE id = ?", (self.client_id,)
            ).fetchone()
            rows = self.db.client_history(self.client_id)
            self.info.setText(f"Historial de {client[0] if client else 'Cliente'}")

        self.table.setRowCount(len(rows))
        for r, row in enumerate(rows):
            if self.vehicle_id:
                values = (
                    f"OT-{row['id']:05d}",
                    self._date(row["fecha"]),
                    name,
                    (vehicle[2] if vehicle and vehicle[2] else "Sin placas"),
                    row["estado"],
                    f"${row['costo']:,.2f}",
                )
            else:
                values = (
                    f"OT-{row['id']:05d}",
                    self._date(row["fecha"]),
                    row.get("vehiculo") or "—",
                    row.get("placas") or "—",
                    row["estado"],
                    f"${row['costo']:,.2f}",
                )
            for c, value in enumerate(values):
                self.table.setItem(r, c, QTableWidgetItem(str(value)))

    @staticmethod
    def _date(value):
        date = QDate.fromString(value or "", DB_DATE)
        return date.toString(SHOW_DATE) if date.isValid() else value or ""


class CrudTab(QWidget):
    def __init__(self, db, entity: Entity, history_mode: str | None = None):
        super().__init__()
        self.db, self.entity = db, entity
        self.history_mode = history_mode
        self.visible_fields = [f for f in entity.fields if f.in_table]
        self.rows: list[dict] = []

        self.search = QLineEdit()
        self.search.setPlaceholderText(f"Buscar en {entity.title.lower()}…")
        self.search.textChanged.connect(self._apply_filter)

        self.add_btn = QPushButton(f"＋  Dar de alta {entity.singular}")
        self.add_btn.setObjectName("primary")
        self.add_btn.clicked.connect(self.add_record)
        self.edit_btn = QPushButton("Editar")
        self.edit_btn.clicked.connect(self.edit_record)
        self.detail_btn = QPushButton("Ver orden")
        self.detail_btn.clicked.connect(self.show_detail)
        self.print_btn = QPushButton("Imprimir")
        self.print_btn.clicked.connect(self.print_order)
        self.pdf_btn = QPushButton("Guardar PDF")
        self.pdf_btn.clicked.connect(self.save_order_pdf)
        self.pay_btn = QPushButton("Registrar pago")
        self.pay_btn.clicked.connect(self.register_payment)
        self.whatsapp_btn = QPushButton("WhatsApp")
        self.whatsapp_btn.clicked.connect(self.send_whatsapp)
        self.history_btn = QPushButton("Ver historial")
        self.history_btn.clicked.connect(self.show_history)
        self.delete_btn = QPushButton("Eliminar")
        self.delete_btn.clicked.connect(self.delete_record)

        top = QHBoxLayout()
        top.setSpacing(10)
        top.addWidget(self.search, 1)
        top.addWidget(self.add_btn)
        top.addWidget(self.edit_btn)
        if entity.table == "ordenes":
            top.addWidget(self.detail_btn)
            top.addWidget(self.print_btn)
            top.addWidget(self.pdf_btn)
            top.addWidget(self.pay_btn)
            top.addWidget(self.whatsapp_btn)
        if history_mode:
            top.addWidget(self.history_btn)
        top.addWidget(self.delete_btn)

        self.table = QTableWidget(0, len(self.visible_fields) + 1)
        self.table.setHorizontalHeaderLabels(["No."] + [f.label for f in self.visible_fields])
        self.table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.table.setAlternatingRowColors(True)
        self.table.setShowGrid(False)
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setStretchLastSection(True)
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Interactive)
        self.table.itemSelectionChanged.connect(self._update_buttons)
        self.table.doubleClicked.connect(self._double_click)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(14)
        layout.addLayout(top)
        layout.addWidget(self.table)
        self.refresh()

    def refresh(self) -> None:
        self.rows = self.db.all(self.entity)
        is_ordenes = self.entity.table == "ordenes"
        pago_status = self.db.orders_payment_status() if is_ordenes else {}
        self.table.setRowCount(len(self.rows))
        for r, record in enumerate(self.rows):
            self.table.setItem(r, 0, QTableWidgetItem(str(record["id"])))
            for c, f in enumerate(self.visible_fields, start=1):
                item = QTableWidgetItem(self._display(record, f))
                if f.key == "estado" and is_ordenes:
                    color = ESTADO_COLORS.get(record.get("estado"))
                    if color:
                        item.setForeground(QColor(color))
                        font = item.font()
                        font.setBold(True)
                        item.setFont(font)
                # El costo se pinta según si la orden ya está cobrada, para
                # ver de un vistazo quién debe dinero sin abrir cada orden.
                if f.key == "costo" and is_ordenes:
                    color = PAGO_COLORS.get(pago_status.get(record["id"]))
                    if color:
                        item.setForeground(QColor(color))
                        font = item.font()
                        font.setBold(True)
                        item.setFont(font)
                self.table.setItem(r, c, item)
        self.table.resizeColumnsToContents()
        self._apply_filter()
        self._update_buttons()

    @staticmethod
    def _display(record: dict, f: Field) -> str:
        value = record.get(f.key)
        if f.kind == "date":
            date = QDate.fromString(value or "", DB_DATE)
            return date.toString(SHOW_DATE) if date.isValid() else (value or "")
        if f.kind == "number":
            return f"${float(value or 0):,.2f}"
        if f.kind == "ref":
            return record.get(f"{f.key}__label") or "—"
        if f.kind == "multiline":
            line = " ".join((value or "").split())
            return line if len(line) <= 60 else line[:57] + "…"
        return str(value or "")

    def _apply_filter(self) -> None:
        text = self.search.text().strip().lower()
        for r in range(self.table.rowCount()):
            haystack = " ".join(
                self.table.item(r, c).text().lower() for c in range(self.table.columnCount())
            )
            self.table.setRowHidden(r, text not in haystack)
        # Si la fila seleccionada quedó oculta por el filtro, se deselecciona:
        # de lo contrario "Eliminar" o "Editar" actuarían sobre un registro
        # que la persona ya no está viendo.
        current = self.table.currentRow()
        if current >= 0 and self.table.isRowHidden(current):
            self.table.clearSelection()
            self.table.setCurrentCell(-1, -1)
        self._update_buttons()

    def _selected(self) -> dict | None:
        row = self.table.currentRow()
        if not (0 <= row < len(self.rows)) or self.table.isRowHidden(row):
            return None
        return self.rows[row]

    def _update_buttons(self) -> None:
        has_selection = self._selected() is not None
        self.edit_btn.setEnabled(has_selection)
        self.delete_btn.setEnabled(has_selection)
        if hasattr(self, "detail_btn"):
            self.detail_btn.setEnabled(has_selection)
        if hasattr(self, "print_btn"):
            self.print_btn.setEnabled(has_selection)
        if hasattr(self, "pdf_btn"):
            self.pdf_btn.setEnabled(has_selection)
        if hasattr(self, "pay_btn"):
            self.pay_btn.setEnabled(has_selection)
        if hasattr(self, "whatsapp_btn"):
            self.whatsapp_btn.setEnabled(has_selection)
        if self.history_mode:
            self.history_btn.setEnabled(has_selection)

    def add_record(self) -> None:
        dialog = RecordDialog(self, self.db, self.entity)
        if dialog.exec():
            try:
                if self.entity.table == "ordenes":
                    self.db.save_order(self.entity, dialog.result_values, dialog.get_items())
                else:
                    self.db.insert(self.entity, dialog.result_values)
            except Exception as error:
                QMessageBox.critical(self, "Error", f"No se pudo guardar el registro.\n\n{error}")
                return
            self.refresh()

    def edit_record(self) -> None:
        record = self._selected()
        if record is None:
            return
        dialog = RecordDialog(self, self.db, self.entity, record)
        if dialog.exec():
            try:
                if self.entity.table == "ordenes":
                    self.db.save_order(self.entity, dialog.result_values, dialog.get_items(), order_id=record["id"])
                else:
                    self.db.update(self.entity, record["id"], dialog.result_values)
            except Exception as error:
                QMessageBox.critical(self, "Error", f"No se pudo actualizar el registro.\n\n{error}")
                return
            self.refresh()

    def _double_click(self, _index) -> None:
        if self.entity.table == "ordenes":
            self.show_detail()
        else:
            self.edit_record()

    def show_detail(self) -> None:
        record = self._selected()
        if record is None or self.entity.table != "ordenes":
            return
        dialog = OrderDetailDialog(self, self.db, record["id"])
        dialog.exec()
        self.refresh()

    def print_order(self) -> None:
        """Imprime la orden seleccionada sin tener que abrir el detalle
        completo primero; usa el mismo servicio que 'Ver orden'."""
        record = self._selected()
        if record is None or self.entity.table != "ordenes":
            return
        from app.order_print import OrderPrintService
        OrderPrintService(self, self.db, record["id"]).print_order()

    def save_order_pdf(self) -> None:
        record = self._selected()
        if record is None or self.entity.table != "ordenes":
            return
        from app.order_print import OrderPrintService
        OrderPrintService(self, self.db, record["id"]).save_pdf()

    def register_payment(self) -> None:
        """Registra un pago para la orden seleccionada sin abrir el detalle."""
        record = self._selected()
        if record is None or self.entity.table != "ordenes":
            return
        from app.payments import register_payment_for
        if register_payment_for(self, self.db, record["id"]):
            self.refresh()

    def send_whatsapp(self) -> None:
        record = self._selected()
        if record is None or self.entity.table != "ordenes":
            return
        from app.whatsapp import open_whatsapp
        row = self.db.order_detail(record["id"])
        if row:
            open_whatsapp(self, row)

    def show_history(self) -> None:
        record = self._selected()
        if not record:
            return
        if self.history_mode == "client":
            dialog = HistoryDialog(
                self, self.db, client_id=record["id"],
                title=f"Historial · {record.get('nombre', 'Cliente')}"
            )
        else:
            dialog = HistoryDialog(
                self, self.db, vehicle_id=record["id"],
                title="Historial del vehículo"
            )
        dialog.exec()

    def delete_record(self) -> None:
        record = self._selected()
        if record is None:
            return
        answer = QMessageBox.question(
            self, "Eliminar", f"¿Eliminar este {self.entity.singular}? No se puede deshacer.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        try:
            self.db.delete(self.entity, record["id"])
        except ValueError as error:
            QMessageBox.warning(self, "No se puede eliminar", str(error))
            return
        self.refresh()
