"""Galería de fotos de una orden de trabajo (evidencia del servicio, daños, avances)."""
from pathlib import Path

from PySide6.QtCore import QSize, Qt
from PySide6.QtGui import QIcon, QPixmap
from PySide6.QtWidgets import (
    QDialog, QFileDialog, QHBoxLayout, QLabel, QListView, QListWidget,
    QListWidgetItem, QMessageBox, QPushButton, QVBoxLayout, QWidget,
)

THUMB_SIZE = 96


class PhotoViewerDialog(QDialog):
    """Ventana simple para ver una foto en tamaño grande."""
    def __init__(self, parent, path: str):
        super().__init__(parent)
        self.setWindowTitle("Foto de la orden")
        self.resize(720, 640)

        label = QLabel()
        label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        pixmap = QPixmap(path)
        if not pixmap.isNull():
            limit = 860
            if pixmap.width() > limit or pixmap.height() > limit:
                pixmap = pixmap.scaled(
                    limit, limit, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation
                )
            label.setPixmap(pixmap)
        else:
            label.setText("No se pudo abrir esta imagen (¿se movió o se borró el archivo?).")

        close = QPushButton("Cerrar")
        close.clicked.connect(self.accept)

        layout = QVBoxLayout(self)
        layout.addWidget(label, 1)
        row = QHBoxLayout(); row.addStretch(); row.addWidget(close)
        layout.addLayout(row)


class PhotoGalleryWidget(QWidget):
    """Miniaturas de las fotos de una orden, con botones para agregar/ver/eliminar.

    Solo funciona sobre una orden ya guardada (necesita el folio para saber en
    qué carpeta archivar las imágenes), por eso vive en el detalle de la orden
    y no en el formulario de alta.
    """
    def __init__(self, parent, db, order_id: int):
        super().__init__(parent)
        self.db = db
        self.order_id = order_id
        self._photos: list[dict] = []

        self.list = QListWidget()
        self.list.setViewMode(QListView.ViewMode.IconMode)
        self.list.setIconSize(QSize(THUMB_SIZE, THUMB_SIZE))
        self.list.setResizeMode(QListView.ResizeMode.Adjust)
        self.list.setMovement(QListView.Movement.Static)
        self.list.setSpacing(8)
        self.list.setFixedHeight(THUMB_SIZE + 48)
        self.list.itemDoubleClicked.connect(self._view_selected)
        self.list.itemSelectionChanged.connect(self._update_buttons)

        self.add_btn = QPushButton("＋ Agregar foto(s)"); self.add_btn.clicked.connect(self._add)
        self.view_btn = QPushButton("Ver"); self.view_btn.clicked.connect(self._view_selected)
        self.delete_btn = QPushButton("Eliminar"); self.delete_btn.clicked.connect(self._delete)
        self.view_btn.setEnabled(False)
        self.delete_btn.setEnabled(False)
        actions = QHBoxLayout()
        actions.addWidget(self.add_btn); actions.addWidget(self.view_btn); actions.addWidget(self.delete_btn)
        actions.addStretch()

        hint = QLabel("Fotos del vehículo o del servicio (daños, avances, evidencia de entrega). Doble clic para ver en grande.")
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#8C8C8C;font-size:11px;")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)
        layout.addWidget(self.list)
        layout.addLayout(actions)
        layout.addWidget(hint)

        self.refresh()

    def refresh(self) -> None:
        self._photos = self.db.order_photos(self.order_id)
        self.list.clear()
        for photo in self._photos:
            pixmap = QPixmap(photo["ruta"])
            item = QListWidgetItem()
            if not pixmap.isNull():
                thumb = pixmap.scaled(
                    THUMB_SIZE, THUMB_SIZE, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation
                )
                item.setIcon(QIcon(thumb))
            item.setToolTip(Path(photo["ruta"]).name)
            item.setData(Qt.ItemDataRole.UserRole, photo["id"])
            self.list.addItem(item)
        self._update_buttons()

    def _selected_photo(self) -> dict | None:
        items = self.list.selectedItems()
        if not items:
            return None
        photo_id = items[0].data(Qt.ItemDataRole.UserRole)
        return next((p for p in self._photos if p["id"] == photo_id), None)

    def _update_buttons(self) -> None:
        has = self._selected_photo() is not None
        self.view_btn.setEnabled(has)
        self.delete_btn.setEnabled(has)

    def _add(self) -> None:
        paths, _ = QFileDialog.getOpenFileNames(
            self, "Elegir foto(s)", "", "Imágenes (*.png *.jpg *.jpeg *.webp *.bmp)"
        )
        if not paths:
            return
        errors = []
        for path in paths:
            try:
                self.db.add_order_photo(self.order_id, path)
            except Exception as error:
                errors.append(str(error))
        self.refresh()
        if errors:
            QMessageBox.critical(self, "Error", "No se pudieron agregar una o más fotos.\n\n" + "\n".join(errors))

    def _view_selected(self) -> None:
        photo = self._selected_photo()
        if not photo:
            return
        PhotoViewerDialog(self, photo["ruta"]).exec()

    def _delete(self) -> None:
        photo = self._selected_photo()
        if not photo:
            return
        answer = QMessageBox.question(
            self, "Eliminar foto", "¿Eliminar esta foto? No se puede deshacer.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.db.delete_order_photo(photo["id"])
        self.refresh()
