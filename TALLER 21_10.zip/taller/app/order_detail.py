from PySide6.QtCore import Qt, QDate
from PySide6.QtWidgets import (
    QAbstractItemView, QDialog, QFrame, QGridLayout, QHBoxLayout, QHeaderView,
    QLabel, QMessageBox, QPushButton, QScrollArea, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QWidget,
)
from app.schema import ESTADOS, ESTADO_COLORS, PAGO_COLORS, payment_state
from app.status_flow import StatusStep

DB_DATE = "yyyy-MM-dd"
SHOW_DATE = "dd/MM/yyyy"


class OrderDetailDialog(QDialog):
    def __init__(self, parent, db, order_id: int):
        super().__init__(parent)
        self.db = db
        self.order_id = order_id
        self.setWindowTitle(f"Detalle de orden · OT-{order_id:05d}")
        self.resize(980, 760)
        self._build()
        self.refresh()

    def _build(self):
        self.title = QLabel()
        self.title.setObjectName("sectionTitle")
        self.subtitle = QLabel()
        self.subtitle.setStyleSheet("color:#8C8C8C;")

        self.status_caption = QLabel()
        self.status_caption.setTextFormat(Qt.TextFormat.RichText)
        self.status_caption.setStyleSheet("color:#8C8C8C;")

        flow = QHBoxLayout(); flow.setSpacing(8)
        self.steps = []
        for i, status in enumerate(ESTADOS):
            step = StatusStep(i, status)
            step.clicked.connect(lambda _=False, s=status: self._set_status(s))
            self.steps.append(step); flow.addWidget(step, 1)
            if i < len(ESTADOS)-1:
                arrow = QLabel("→"); arrow.setAlignment(Qt.AlignmentFlag.AlignCenter)
                arrow.setStyleSheet("color:#555;font-size:24px;font-weight:700;")
                flow.addWidget(arrow)

        self.info_frame = QFrame(); self.info_frame.setObjectName("card")
        grid = QGridLayout(self.info_frame); grid.setContentsMargins(18,16,18,16); grid.setHorizontalSpacing(30); grid.setVerticalSpacing(12)
        self.labels = {}
        fields = [
            ("Cliente", "cliente"), ("Vehículo", "vehiculo"), ("Placas", "placas"),
            ("Kilometraje", "kilometraje"), ("Fecha de ingreso", "fecha"),
            ("Fecha de cierre", "fecha_cierre"), ("Notas", "notas"),
        ]
        for row, (caption, key) in enumerate(fields):
            cap = QLabel(caption); cap.setStyleSheet("color:#8C8C8C;font-size:12px;")
            val = QLabel(); val.setWordWrap(True); val.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
            self.labels[key] = val
            grid.addWidget(cap, row, 0); grid.addWidget(val, row, 1)
        self.labels["notas"].setMinimumHeight(45)

        self.total=QLabel(); self.paid=QLabel(); self.balance=QLabel(); self.payment_state=QLabel()
        for w in (self.total,self.paid,self.balance,self.payment_state): w.setObjectName("sectionTitle")
        self.over_warning = QLabel(); self.over_warning.setWordWrap(True)
        self.over_warning.setStyleSheet("color:#dc2626;font-weight:600;")
        self.over_warning.hide()
        money=QHBoxLayout(); money.addWidget(self._money_card("Total",self.total)); money.addWidget(self._money_card("Pagado",self.paid)); money.addWidget(self._money_card("Saldo",self.balance)); money.addWidget(self._money_card("Estado",self.payment_state))

        items_title = QLabel("Conceptos / servicios"); items_title.setObjectName("sectionTitle")
        self.items_table = QTableWidget(0, 4)
        self.items_table.setHorizontalHeaderLabels(["Descripción", "Cantidad", "Precio unit.", "Subtotal"])
        self._prep_table(self.items_table, height=150)
        self.item_add = QPushButton("＋ Agregar concepto"); self.item_add.clicked.connect(self._add_item)
        self.item_edit = QPushButton("Editar"); self.item_edit.clicked.connect(self._edit_item)
        self.item_delete = QPushButton("Eliminar"); self.item_delete.clicked.connect(self._delete_item)
        self.items_table.itemSelectionChanged.connect(self._update_item_buttons)
        items_actions = QHBoxLayout(); items_actions.addWidget(self.item_add); items_actions.addWidget(self.item_edit); items_actions.addWidget(self.item_delete); items_actions.addStretch()
        self.items_hint = QLabel("El costo total de la orden es la suma de sus conceptos.")
        self.items_hint.setStyleSheet("color:#8C8C8C;font-size:11px;")

        payments_title = QLabel("Pagos registrados"); payments_title.setObjectName("sectionTitle")
        self.payments_table = QTableWidget(0, 5)
        self.payments_table.setHorizontalHeaderLabels(["Fecha", "Monto", "Método", "Referencia", "Notas"])
        self._prep_table(self.payments_table, height=130)
        self.payment_edit = QPushButton("Editar pago"); self.payment_edit.clicked.connect(self._edit_payment)
        self.payment_delete = QPushButton("Eliminar pago"); self.payment_delete.clicked.connect(self._delete_payment)
        self.payments_table.itemSelectionChanged.connect(self._update_payment_buttons)
        payments_actions = QHBoxLayout(); payments_actions.addWidget(self.payment_edit); payments_actions.addWidget(self.payment_delete); payments_actions.addStretch()

        from app.photos import PhotoGalleryWidget
        photos_title = QLabel("Fotos"); photos_title.setObjectName("sectionTitle")
        self.photos_gallery = PhotoGalleryWidget(self, self.db, self.order_id)

        self.edit_btn=QPushButton("Editar orden"); self.edit_btn.clicked.connect(self._edit)
        self.print_btn=QPushButton("Imprimir")
        self.print_btn.clicked.connect(self._print)
        self.pdf_btn=QPushButton("Guardar PDF")
        self.pdf_btn.clicked.connect(self._pdf)
        self.pay_btn=QPushButton("Registrar pago"); self.pay_btn.setObjectName("primary"); self.pay_btn.clicked.connect(self._pay)
        self.whatsapp_btn=QPushButton("WhatsApp"); self.whatsapp_btn.clicked.connect(self._whatsapp)
        close=QPushButton("Cerrar"); close.clicked.connect(self.accept)
        buttons=QHBoxLayout(); buttons.addWidget(self.edit_btn); buttons.addWidget(self.print_btn); buttons.addWidget(self.pdf_btn); buttons.addWidget(self.whatsapp_btn); buttons.addWidget(self.pay_btn); buttons.addStretch(); buttons.addWidget(close)

        layout=QVBoxLayout(self); layout.setContentsMargins(24,22,24,20); layout.setSpacing(12)

        # Todo el contenido (info, conceptos, pagos) va dentro de un área con
        # scroll, para que en pantallas chicas o con muchos conceptos/pagos
        # los botones de abajo (Editar, Imprimir, PDF, Cobrar, Cerrar) siempre
        # queden visibles y no se corten.
        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(12)
        content_layout.addWidget(self.title); content_layout.addWidget(self.subtitle)
        content_layout.addWidget(self.status_caption); content_layout.addLayout(flow); content_layout.addWidget(self.info_frame); content_layout.addLayout(money); content_layout.addWidget(self.over_warning)
        content_layout.addWidget(items_title); content_layout.addWidget(self.items_table)
        content_layout.addLayout(items_actions); content_layout.addWidget(self.items_hint)
        content_layout.addWidget(payments_title); content_layout.addWidget(self.payments_table)
        content_layout.addLayout(payments_actions)
        content_layout.addWidget(photos_title); content_layout.addWidget(self.photos_gallery)
        content_layout.addStretch()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.Shape.NoFrame)
        scroll.setWidget(content)

        layout.addWidget(scroll)
        layout.addLayout(buttons)

    @staticmethod
    def _prep_table(table, height=140):
        table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        table.setAlternatingRowColors(True)
        table.setShowGrid(False)
        table.verticalHeader().setVisible(False)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeMode.Stretch)
        table.setMaximumHeight(height)

    def _money_card(self, caption, label):
        frame=QFrame(); frame.setObjectName("card"); lay=QVBoxLayout(frame); lay.setContentsMargins(14,10,14,10)
        c=QLabel(caption); c.setStyleSheet("color:#8C8C8C;font-size:12px;"); lay.addWidget(c); lay.addWidget(label); return frame

    def refresh(self):
        row=self.db.order_detail(self.order_id)
        if not row:
            self.reject(); return
        self.current=row.get("estado") or ESTADOS[0]
        self.title.setText(f"Orden de trabajo <b>OT-{self.order_id:05d}</b>")
        self.subtitle.setText(f"{row.get('cliente') or 'Sin cliente'} · {row.get('vehiculo') or 'Sin vehículo'}")
        self.labels["cliente"].setText(row.get("cliente") or "—")
        self.labels["vehiculo"].setText(row.get("vehiculo") or "—")
        self.labels["placas"].setText(row.get("placas") or "Sin placas")
        self.labels["kilometraje"].setText(row.get("kilometraje") or "—")
        d=QDate.fromString(row.get("fecha") or "", DB_DATE)
        self.labels["fecha"].setText(d.toString(SHOW_DATE) if d.isValid() else row.get("fecha") or "—")
        dc=QDate.fromString(row.get("fecha_cierre") or "", DB_DATE)
        self.labels["fecha_cierre"].setText(dc.toString(SHOW_DATE) if dc.isValid() else "—")
        self.labels["notas"].setText(row.get("notas") or "—")
        total=float(row.get("costo") or 0); paid=float(row.get("pagado") or 0); balance=max(0,total-paid)
        self.total.setText(f"${total:,.2f}"); self.paid.setText(f"${paid:,.2f}"); self.balance.setText(f"${balance:,.2f}")
        estado_pago = payment_state(total, paid)
        self.payment_state.setText(estado_pago)
        self.payment_state.setStyleSheet(f"color:{PAGO_COLORS.get(estado_pago, '#EDEDED')};font-weight:700;")
        self.pay_btn.setEnabled(balance>.005)
        if paid > total + .005:
            self.over_warning.setText(
                f"⚠ Lo pagado (${paid:,.2f}) es mayor que el total de la orden (${total:,.2f}). "
                "Revisa los conceptos o los pagos registrados."
            )
            self.over_warning.show()
        else:
            self.over_warning.hide()
        color = ESTADO_COLORS.get(self.current, '#EDEDED')
        self.status_caption.setText(
            f"Estado actual: <b style='color:{color}'>{self.current}</b>  ·  toca otra etapa para cambiarlo"
        )
        for step in self.steps: step.set_active(step.title==self.current)
        self._refresh_items()
        self._refresh_payments()

    # ---------- conceptos ----------
    def _refresh_items(self):
        items = self.db.order_items(self.order_id)
        self._items = items
        self.items_table.setRowCount(len(items))
        for r, item in enumerate(items):
            values = (
                item["descripcion"],
                f"{item['cantidad']:g}",
                f"${item['precio_unitario']:,.2f}",
                f"${item['subtotal']:,.2f}",
            )
            for c, v in enumerate(values):
                self.items_table.setItem(r, c, QTableWidgetItem(str(v)))
        self._update_item_buttons()

    def _selected_item(self):
        row = self.items_table.currentRow()
        return self._items[row] if 0 <= row < len(self._items) else None

    def _update_item_buttons(self):
        has = self._selected_item() is not None
        self.item_edit.setEnabled(has)
        self.item_delete.setEnabled(has)

    def _add_item(self):
        from app.order_items import OrderItemDialog
        dlg = OrderItemDialog(self, self.db)
        if dlg.exec() and dlg.result_values:
            self.db.add_order_item(self.order_id, **dlg.result_values)
            self.refresh()

    def _edit_item(self):
        item = self._selected_item()
        if not item:
            return
        from app.order_items import OrderItemDialog
        dlg = OrderItemDialog(self, self.db, item)
        if dlg.exec() and dlg.result_values:
            self.db.update_order_item(item["id"], **dlg.result_values)
            self.refresh()

    def _delete_item(self):
        item = self._selected_item()
        if not item:
            return
        if len(self._items) <= 1:
            QMessageBox.information(
                self, "No se puede eliminar",
                "Una orden debe tener al menos un concepto. Agrega primero el nuevo "
                "concepto y luego elimina este, o usa «Editar» para cambiarlo.",
            )
            return
        answer = QMessageBox.question(
            self, "Eliminar concepto", "¿Eliminar este concepto de la orden?",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.db.delete_order_item(item["id"])
        self.refresh()

    # ---------- pagos ----------
    def _refresh_payments(self):
        payments = self.db.payments_for_order(self.order_id)
        self._payments = payments
        self.payments_table.setRowCount(len(payments))
        for r, p in enumerate(payments):
            d = QDate.fromString(p["fecha"] or "", DB_DATE)
            fecha = d.toString(SHOW_DATE) if d.isValid() else (p["fecha"] or "—")
            values = (fecha, f"${p['monto']:,.2f}", p["metodo"], p.get("referencia") or "—", p.get("notas") or "—")
            for c, v in enumerate(values):
                self.payments_table.setItem(r, c, QTableWidgetItem(str(v)))
        self._update_payment_buttons()

    def _selected_payment(self):
        row = self.payments_table.currentRow()
        return self._payments[row] if 0 <= row < len(self._payments) else None

    def _update_payment_buttons(self):
        has = self._selected_payment() is not None
        self.payment_edit.setEnabled(has)
        self.payment_delete.setEnabled(has)

    def _edit_payment(self):
        payment = self._selected_payment()
        if not payment:
            return
        from app.payments import PaymentEditDialog
        dlg = PaymentEditDialog(self, self.db, payment)
        if dlg.exec():
            self.refresh()

    def _delete_payment(self):
        payment = self._selected_payment()
        if not payment:
            return
        answer = QMessageBox.question(
            self, "Eliminar pago", "¿Eliminar este pago? No se puede deshacer.",
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
            QMessageBox.StandardButton.No,
        )
        if answer != QMessageBox.StandardButton.Yes:
            return
        self.db.delete_payment(payment["id"])
        self.refresh()

    # ---------- estado, edición, impresión, pago ----------
    def _set_status(self, status):
        if status != self.current:
            self.db.update_order_status(self.order_id, status)
        # Siempre se refresca: si se dio clic en la etapa ya seleccionada, Qt la
        # deja visualmente sin marcar (por ser un botón "checkable" normal) y
        # hay que forzar que vuelva a verse activa.
        self.refresh()

    def _edit(self):
        from app.crud import RecordDialog
        from app.schema import ORDENES
        record=self.db.order_record(self.order_id)
        dlg=RecordDialog(self,self.db,ORDENES,record)
        if dlg.exec():
            try:
                self.db.save_order(ORDENES, dlg.result_values, dlg.get_items(), order_id=self.order_id)
            except Exception as e: QMessageBox.critical(self,"Error",f"No se pudo actualizar la orden.\n\n{e}"); return
            self.refresh()

    def _print(self):
        from app.order_print import OrderPrintService
        OrderPrintService(self, self.db, self.order_id).print_order()

    def _pdf(self):
        from app.order_print import OrderPrintService
        OrderPrintService(self, self.db, self.order_id).save_pdf()

    def _pay(self):
        from app.payments import register_payment_for
        if register_payment_for(self, self.db, self.order_id):
            self.refresh()

    def _whatsapp(self):
        from app.whatsapp import open_whatsapp
        row = self.db.order_detail(self.order_id)
        if row:
            open_whatsapp(self, row)
