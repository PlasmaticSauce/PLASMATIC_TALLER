"""Modelo de datos del sistema del taller.

La aplicación se construye a partir de estas entidades. Clientes, vehículos y
órdenes están relacionados para conservar el historial completo de cada unidad.
"""
from dataclasses import dataclass


@dataclass(frozen=True)
class Field:
    key: str
    label: str
    kind: str = "text"  # text | multiline | number | date | choice | ref
    required: bool = False
    options: tuple[str, ...] = ()
    ref: str = ""
    in_table: bool = True


@dataclass(frozen=True)
class Entity:
    table: str
    title: str
    singular: str
    fields: tuple[Field, ...]


ESTADOS = (
    "Recibido",
    "Diagnóstico",
    "Terminado",
)
ESTADOS_CERRADOS = ("Terminado",)
ESTADO_COBRADO = "Terminado"
METODOS_PAGO = ("Efectivo", "Transferencia", "Tarjeta", "Depósito", "Otro")

# Colores "semáforo" usados en todo el programa (flujo de estado de la orden,
# tabla de órdenes, badge de pago, y el PDF) para que de un vistazo se note
# en qué etapa va una orden y si ya se cobró.
ESTADO_COLORS = {
    "Recibido": "#dc2626",      # rojo: acaba de entrar
    "Diagnóstico": "#d97706",   # ámbar: en proceso
    "Terminado": "#16a34a",     # verde: listo
}
PAGO_COLORS = {
    "Pendiente": "#dc2626",     # rojo: no se ha cobrado nada
    "Parcial": "#d97706",       # ámbar: cobro parcial
    "Pagado": "#16a34a",        # verde: ya se cobró completo
}


def payment_state(total: float, paid: float) -> str:
    """Estado de cobro de una orden (Pendiente / Parcial / Pagado).

    Es la única definición: la usan la lista de órdenes, el detalle, Reportes
    y el Dashboard, para que nunca se contradigan entre sí.
    """
    balance = max(0.0, total - paid)
    if total > 0 and balance <= 0.005:
        return "Pagado"
    return "Parcial" if paid > 0 else "Pendiente"

CLIENTES = Entity(
    "clientes", "Clientes", "cliente",
    (
        Field("nombre", "Nombre", required=True),
        Field("telefono", "Teléfono"),
        Field("correo", "Correo"),
        Field("direccion", "Dirección"),
        Field("notas", "Notas", "multiline", in_table=False),
    ),
)

VEHICULOS = Entity(
    "vehiculos", "Vehículos", "vehículo",
    (
        Field("cliente_id", "Cliente", "ref", required=True, ref="clientes"),
        Field("marca", "Marca", required=True),
        Field("modelo", "Modelo", required=True),
        Field("anio", "Año"),
        Field("version", "Versión"),
        Field("placas", "Placas"),
        Field("vin", "VIN / NIV"),
        Field("kilometraje", "Kilometraje"),
        Field("color", "Color"),
        Field("notas", "Notas", "multiline", in_table=False),
    ),
)

PROVEEDORES = Entity(
    "proveedores", "Proveedores", "proveedor",
    (
        Field("empresa", "Empresa", required=True),
        Field("contacto", "Contacto"),
        Field("telefono", "Teléfono"),
        Field("correo", "Correo"),
        Field("productos", "Productos que surte", "multiline"),
        Field("notas", "Notas", "multiline", in_table=False),
    ),
)

SERVICIOS = Entity(
    "servicios", "Servicios", "servicio",
    (
        Field("nombre", "Servicio", required=True),
        Field("precio", "Precio", "number", required=True),
        Field("descripcion", "Descripción", "multiline", in_table=False),
    ),
)

ORDENES = Entity(
    "ordenes", "Órdenes de trabajo", "orden",
    (
        Field("fecha", "Fecha de ingreso", "date", required=True),
        Field("cliente_id", "Cliente", "ref", required=True, ref="clientes"),
        Field("vehiculo_id", "Vehículo", "ref", required=True, ref="vehiculos"),
        Field("servicio", "Servicio a realizar", "multiline", required=False),
        Field("estado", "Estado", "choice", options=ESTADOS),
        Field("costo", "Costo total", "number"),
        Field("notas", "Notas", "multiline", in_table=False),
    ),
)

# El orden importa: las tablas referenciadas deben existir antes de las que las usan.
ENTITIES = {e.table: e for e in (CLIENTES, VEHICULOS, PROVEEDORES, SERVICIOS, ORDENES)}
