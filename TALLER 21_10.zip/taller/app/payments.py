"""Control de pagos de órdenes de trabajo.

Los pagos se registran, editan y borran siempre desde la orden a la que
pertenecen (ver app/order_detail.py): no hay una pestaña aparte para esto,
para no repetir la misma acción en dos lugares distintos del programa.
"""
from PySide6.QtCore import QDate
from PySide6.QtWidgets import (
    QComboBox, QDateEdit, QDialog, QDialogButtonBox, QDoubleSpinBox,
    QFormLayout, QFrame, QLabel, QLineEdit, QMessageBox, QPlainTextEdit,
    QScrollArea, QVBoxLayout, QWidget,
)

from app.widgets import make_searchable, sync_combo_text

DB_DATE = "yyyy-MM-dd"
SHOW_DATE = "dd/MM/yyyy"
METHODS = ("Efectivo", "Transferencia", "Tarjeta", "Depósito", "Otro")


def _scrollable(form_layout) -> QScrollArea:
    """Envuelve un formulario en un área con scroll, para que en pantallas
    chicas los campos de abajo no queden escondidos fuera de la vista."""
    content = QWidget()
    content_layout = QVBoxLayout(content)
    content_layout.setContentsMargins(0, 0, 0, 0)
    content_layout.addLayout(form_layout)
    content_layout.addStretch()
    scroll = QScrollArea()
    scroll.setWidgetResizable(True)
    scroll.setFrameShape(QFrame.Shape.NoFrame)
    scroll.setWidget(content)
    return scroll


class PaymentDialog(QDialog):
    def __init__(self, parent, db):
        super().__init__(parent)
        self.db = db
        self.result = None
        self.setWindowTitle("Registrar pago")
        self.setMinimumWidth(520)

        self.order = QComboBox()
        self.amount = QDoubleSpinBox()
        self.amount.setRange(0.01, 99_999_999)
        self.amount.setDecimals(2)
        self.amount.setPrefix("$ ")
        self.amount.setGroupSeparatorShown(True)
        self.method = QComboBox(); self.method.addItems(METHODS)
        self.date = QDateEdit(QDate.currentDate()); self.date.setCalendarPopup(True); self.date.setDisplayFormat(SHOW_DATE)
        self.reference = QLineEdit(); self.reference.setPlaceholderText("Folio, referencia o últimos 4 dígitos")
        self.notes = QPlainTextEdit(); self.notes.setFixedHeight(70)

        self.info = QLabel(); self.info.setObjectName("sectionTitle")
        self.order.currentIndexChanged.connect(self._order_changed)
        self._load_orders()
        # Se puede escribir para buscar la orden (por cliente, vehículo o folio).
        make_searchable(self.order)

        form = QFormLayout(); form.setSpacing(12)
        form.addRow("Orden *", self.order)
        form.addRow("Saldo", self.info)
        form.addRow("Monto *", self.amount)
        form.addRow("Método", self.method)
        form.addRow("Fecha", self.date)
        form.addRow("Referencia", self.reference)
        form.addRow("Notas", self.notes)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Registrar")
        buttons.button(QDialogButtonBox.StandardButton.Save).setObjectName("primary")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        buttons.accepted.connect(self._save); buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self); layout.setContentsMargins(24,24,24,20); layout.setSpacing(16)
        layout.addWidget(_scrollable(form)); layout.addWidget(buttons)

    def _load_orders(self):
        rows = self.db.payment_order_options()
        for r in rows:
            self.order.addItem(r["label"], r["id"])
        self._order_changed()

    def _order_changed(self):
        oid = self.order.currentData()
        if not oid:
            self.info.setText("Sin órdenes disponibles")
            self.amount.setMaximum(0.01)
            return
        bal = self.db.order_balance(oid)
        self.info.setText(f"${bal:,.2f}")
        self.amount.setMaximum(max(0.01, bal))
        if bal > 0:
            self.amount.setValue(bal)

    def _save(self):
        if not sync_combo_text(self.order, strict=True):
            QMessageBox.warning(
                self, "Elige una orden de la lista",
                "Lo que escribiste en «Orden» no coincide con ninguna orden con saldo. "
                "Escribe para buscar y elige una de la lista desplegable.",
            )
            self.order.setFocus()
            return
        oid = self.order.currentData()
        amount = self.amount.value()
        if not oid:
            QMessageBox.warning(self, "Falta información", "Selecciona una orden.")
            return
        balance = self.db.order_balance(oid)
        if amount <= 0 or amount > balance + 0.005:
            QMessageBox.warning(self, "Monto inválido", f"El pago debe ser mayor a cero y no superar el saldo de ${balance:,.2f}.")
            return
        self.result = {
            "orden_id": oid, "monto": amount, "metodo": self.method.currentText(),
            "fecha": self.date.date().toString(DB_DATE), "referencia": self.reference.text().strip(),
            "notas": self.notes.toPlainText().strip(),
        }
        self.accept()


class PaymentEditDialog(QDialog):
    """Editar un pago ya registrado (sin poder cambiar la orden a la que pertenece)."""
    def __init__(self, parent, db, payment: dict):
        super().__init__(parent)
        self.db = db
        self.payment = payment
        self.setWindowTitle(f"Editar pago · OT-{payment['orden_id']:05d}")
        self.setMinimumWidth(480)

        self.amount = QDoubleSpinBox()
        self.amount.setRange(0.01, 99_999_999)
        self.amount.setDecimals(2)
        self.amount.setPrefix("$ ")
        self.amount.setGroupSeparatorShown(True)
        self.amount.setValue(float(payment["monto"] or 0))
        self.method = QComboBox(); self.method.addItems(METHODS)
        self.method.setCurrentText(payment["metodo"] or METHODS[0])
        self.date = QDateEdit(); self.date.setCalendarPopup(True); self.date.setDisplayFormat(SHOW_DATE)
        d = QDate.fromString(payment["fecha"] or "", DB_DATE)
        self.date.setDate(d if d.isValid() else QDate.currentDate())
        self.reference = QLineEdit(payment.get("referencia") or "")
        self.notes = QPlainTextEdit(); self.notes.setFixedHeight(70); self.notes.setPlainText(payment.get("notas") or "")

        form = QFormLayout(); form.setSpacing(12)
        form.addRow("Monto *", self.amount)
        form.addRow("Método", self.method)
        form.addRow("Fecha", self.date)
        form.addRow("Referencia", self.reference)
        form.addRow("Notas", self.notes)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.button(QDialogButtonBox.StandardButton.Save).setText("Guardar")
        buttons.button(QDialogButtonBox.StandardButton.Save).setObjectName("primary")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        buttons.accepted.connect(self._save); buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self); layout.setContentsMargins(24,24,24,20); layout.setSpacing(16)
        layout.addWidget(_scrollable(form)); layout.addWidget(buttons)

    def _save(self):
        try:
            self.db.update_payment(
                self.payment["id"], self.amount.value(), self.method.currentText(),
                self.date.date().toString(DB_DATE), self.reference.text().strip(),
                self.notes.toPlainText().strip(),
            )
        except ValueError as error:
            QMessageBox.warning(self, "Monto inválido", str(error))
            return
        self.accept()


def register_payment_for(parent, db, order_id: int) -> bool:
    """Abre el formulario de pago para UNA orden concreta y lo registra.

    Es el único camino que usan la lista de Órdenes, el detalle de la orden y
    Reportes. Antes cada uno armaba su propio formulario y, si la orden ya
    estaba pagada (por lo que no aparece en la lista del formulario), éste
    dejaba seleccionada OTRA orden sin avisar. Aquí se valida primero.

    Devuelve True si se registró un pago.
    """
    record = db.order_record(order_id)
    if not record:
        QMessageBox.warning(parent, "Orden no encontrada", "Esa orden ya no existe.")
        return False
    if float(record.get("costo") or 0) <= 0:
        QMessageBox.information(
            parent, "Orden sin total",
            f"La orden OT-{order_id:05d} todavía no tiene un total (costo $0.00).\n"
            "Agrega conceptos con su precio antes de registrar pagos.",
        )
        return False
    if db.order_balance(order_id) <= 0.005:
        QMessageBox.information(
            parent, "Orden ya pagada",
            f"La orden OT-{order_id:05d} ya está pagada por completo; no tiene saldo pendiente.",
        )
        return False
    dialog = PaymentDialog(parent, db)
    index = dialog.order.findData(order_id)
    if index < 0:
        QMessageBox.warning(parent, "Orden no disponible", "No se pudo preparar el pago de esa orden.")
        return False
    dialog.order.setCurrentIndex(index)
    if not (dialog.exec() and dialog.result):
        return False
    try:
        db.add_payment(**dialog.result)
    except Exception as error:
        QMessageBox.critical(parent, "Error", f"No se pudo registrar el pago.\n\n{error}")
        return False
    return True
