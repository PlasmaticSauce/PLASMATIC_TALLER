"""Enviar un mensaje de WhatsApp al cliente de una orden.

No usa ninguna cuenta de WhatsApp Business ni API de pago: simplemente abre
un chat de WhatsApp (web o la app de escritorio, lo que el usuario tenga
configurado) con el número y el mensaje ya listos, usando el enlace público
"wa.me". Quien manda el mensaje es la persona, dando clic en "Enviar" dentro
de WhatsApp — el programa solo prepara el chat.
"""
import re
from urllib.parse import quote

from PySide6.QtCore import QUrl
from PySide6.QtGui import QDesktopServices
from PySide6.QtWidgets import (
    QDialog, QDialogButtonBox, QFormLayout, QLabel, QLineEdit, QMessageBox,
    QPlainTextEdit, QVBoxLayout,
)

from app.config import TALLER_NOMBRE

PAIS_DEFECTO = "52"  # México; se antepone solo si el teléfono no trae código de país


def clean_phone(raw: str) -> str:
    """Deja solo dígitos y antepone el código de país si hace falta.

    Si el número tiene 10 dígitos (formato típico de celular en México sin
    código de país), se le antepone "52". Si ya trae más dígitos, se asume
    que el código de país ya está incluido y se deja tal cual.
    """
    digits = re.sub(r"\D", "", raw or "")
    # Prefijos antiguos de marcación a celular en México ("044"/"045" + 10
    # dígitos); WhatsApp no los entiende, hay que quitarlos.
    if len(digits) == 13 and digits[:3] in ("044", "045"):
        digits = digits[3:]
    if len(digits) == 10:
        digits = PAIS_DEFECTO + digits
    return digits


def build_message(row: dict) -> str:
    cliente = (row.get("cliente") or "").split()[0] if row.get("cliente") else ""
    saludo = f"Hola {cliente}," if cliente else "Hola,"
    total = float(row.get("costo") or 0)
    pagado = float(row.get("pagado") or 0)
    saldo = max(0.0, total - pagado)
    estado = row.get("estado") or ""
    folio = f"OT-{row.get('id'):05d}" if row.get("id") else ""
    vehiculo = row.get("vehiculo") or ""

    lineas = [
        f"{saludo} te escribimos de {TALLER_NOMBRE} sobre tu orden {folio}"
        + (f" ({vehiculo})" if vehiculo else "") + ".",
        f"Estado actual: {estado}.",
    ]
    if total > 0:
        if saldo <= 0.005:
            lineas.append(f"Tu orden ya está pagada por completo (${total:,.2f}).")
        else:
            lineas.append(f"Total: ${total:,.2f}  ·  Saldo pendiente: ${saldo:,.2f}.")
    lineas.append("Quedamos al pendiente, saludos.")
    return "\n".join(lineas)


class WhatsAppDialog(QDialog):
    """Deja revisar/editar el teléfono y el mensaje antes de abrir WhatsApp."""
    def __init__(self, parent, row: dict):
        super().__init__(parent)
        self.setWindowTitle("Enviar WhatsApp")
        self.setMinimumWidth(480)

        self.phone = QLineEdit(row.get("cliente_telefono") or "")
        self.phone.setPlaceholderText("10 dígitos, p. ej. 5512345678")
        self.message = QPlainTextEdit(build_message(row))
        self.message.setFixedHeight(160)

        hint = QLabel(
            "Se abrirá WhatsApp con el chat y el mensaje ya listos; tú le das "
            "Enviar desde ahí. Puedes editar el número o el texto antes de abrirlo."
        )
        hint.setWordWrap(True)
        hint.setStyleSheet("color:#8C8C8C;font-size:11px;")

        form = QFormLayout()
        form.setSpacing(12)
        form.addRow("Teléfono *", self.phone)
        form.addRow("Mensaje", self.message)

        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Cancel)
        open_btn = buttons.addButton("Abrir WhatsApp", QDialogButtonBox.ButtonRole.AcceptRole)
        open_btn.setObjectName("primary")
        buttons.button(QDialogButtonBox.StandardButton.Cancel).setText("Cancelar")
        buttons.accepted.connect(self._open)
        buttons.rejected.connect(self.reject)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 24, 24, 20)
        layout.setSpacing(14)
        layout.addWidget(hint)
        layout.addLayout(form)
        layout.addWidget(buttons)

    def _open(self) -> None:
        digits = clean_phone(self.phone.text())
        if len(digits) < 10:
            QMessageBox.warning(
                self, "Teléfono inválido",
                "Escribe un número de teléfono válido (al menos 10 dígitos)."
            )
            return
        text = quote(self.message.toPlainText())
        url = QUrl(f"https://wa.me/{digits}?text={text}")
        QDesktopServices.openUrl(url)
        self.accept()


def open_whatsapp(parent, row: dict) -> None:
    if not row.get("cliente_telefono"):
        QMessageBox.information(
            parent, "Sin teléfono",
            "Este cliente no tiene teléfono registrado. Puedes escribirlo "
            "aquí mismo antes de abrir WhatsApp, o agregarlo luego en su ficha."
        )
    WhatsAppDialog(parent, row).exec()
