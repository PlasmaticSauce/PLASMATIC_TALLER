"""Ayudas de interfaz reutilizables.

Combos con búsqueda ("escribe una letra y se filtra la lista")
--------------------------------------------------------------
Un QComboBox editable tiene una trampa: lo que se VE en el cuadro de texto
y lo que está REALMENTE seleccionado pueden ser cosas distintas. Si la
persona escribe "mar" para buscar a "Marta" pero no hace clic en el
resultado, el texto dice "mar" mientras que por dentro sigue seleccionado el
cliente anterior, y al guardar se usaría ese cliente equivocado sin avisar.

`make_searchable` activa la búsqueda y además garantiza que, al salir del
campo o al guardar, el texto visible coincida siempre con la opción real.
"""
from PySide6.QtCore import Qt
from PySide6.QtWidgets import QComboBox, QCompleter


def _find_match(combo: QComboBox, typed: str) -> int:
    """Índice de la opción que corresponde a lo escrito, o -1 si no hay una
    única opción clara (coincidencia exacta, o una sola que lo contenga)."""
    text = typed.strip().lower()
    if not text:
        return -1
    for i in range(combo.count()):
        if combo.itemText(i).strip().lower() == text:
            return i
    matches = [i for i in range(combo.count()) if text in combo.itemText(i).lower()]
    return matches[0] if len(matches) == 1 else -1


def sync_combo_text(combo: QComboBox, strict: bool = False) -> bool:
    """Hace que el texto visible del combo coincida con la opción seleccionada.

    - Si lo escrito identifica una sola opción, la selecciona.
    - Si no, el texto vuelve a mostrar la opción que sigue seleccionada
      (así nunca se queda un texto engañoso en pantalla).
    - Con ``strict=True`` devuelve False cuando la persona escribió algo que
      no corresponde a ninguna opción, para poder avisarle antes de guardar.
    """
    typed = combo.currentText()
    index = combo.currentIndex()
    current_text = combo.itemText(index) if index >= 0 else ""
    if typed == current_text:
        return True
    found = _find_match(combo, typed)
    if found >= 0:
        combo.setCurrentIndex(found)
        combo.setEditText(combo.itemText(found))
        return True
    if strict and typed.strip():
        return False
    combo.setEditText(current_text)
    return True


def make_searchable(combo: QComboBox) -> None:
    """Permite escribir en el combo para filtrar sus opciones (coincidencia
    en cualquier parte del texto, sin importar mayúsculas)."""
    combo.setEditable(True)
    combo.setInsertPolicy(QComboBox.InsertPolicy.NoInsert)
    completer = combo.completer()
    if completer is not None:
        completer.setCompletionMode(QCompleter.CompletionMode.PopupCompletion)
        completer.setFilterMode(Qt.MatchFlag.MatchContains)
        completer.setCaseSensitivity(Qt.CaseSensitivity.CaseInsensitive)
    line_edit = combo.lineEdit()
    if line_edit is not None:
        # Al salir del campo (o dar Enter) se reconcilia texto y selección.
        line_edit.editingFinished.connect(lambda c=combo: sync_combo_text(c))
